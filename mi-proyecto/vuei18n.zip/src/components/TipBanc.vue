<template>
<div>
  <h1>{{ $t("tip_bancoX") }}</h1>       
</div>
</template>
 
<script>
export default {
  name: "AppNAV",
  data() {
    return {
      LoadingTrue: 0,
      datos: [],
      langs: ["es", "en"]
    }
}
}
</script>


