import Vue from 'vue'
export default i18n


export default new Router({
 
})